﻿namespace otel_otomasyon
{
    partial class yenimusteri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(yenimusteri));
            this.musterikayitpanel = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.odaturukutu = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.soyadkutu = new System.Windows.Forms.TextBox();
            this.temizlebutonu = new System.Windows.Forms.Button();
            this.kayitbutonu = new System.Windows.Forms.Button();
            this.kalacaksurekutu = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cikistarihikutu = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.giristarihikutu = new System.Windows.Forms.DateTimePicker();
            this.cinsiyetkutu = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.odanokutu = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.medenihal = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.telefonnokutu = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.adkutu = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tckimliknokutu = new System.Windows.Forms.TextBox();
            this.musterikayitpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // musterikayitpanel
            // 
            this.musterikayitpanel.Controls.Add(this.label14);
            this.musterikayitpanel.Controls.Add(this.odaturukutu);
            this.musterikayitpanel.Controls.Add(this.label7);
            this.musterikayitpanel.Controls.Add(this.label13);
            this.musterikayitpanel.Controls.Add(this.soyadkutu);
            this.musterikayitpanel.Controls.Add(this.temizlebutonu);
            this.musterikayitpanel.Controls.Add(this.kayitbutonu);
            this.musterikayitpanel.Controls.Add(this.kalacaksurekutu);
            this.musterikayitpanel.Controls.Add(this.label12);
            this.musterikayitpanel.Controls.Add(this.label11);
            this.musterikayitpanel.Controls.Add(this.cikistarihikutu);
            this.musterikayitpanel.Controls.Add(this.label6);
            this.musterikayitpanel.Controls.Add(this.giristarihikutu);
            this.musterikayitpanel.Controls.Add(this.cinsiyetkutu);
            this.musterikayitpanel.Controls.Add(this.label4);
            this.musterikayitpanel.Controls.Add(this.odanokutu);
            this.musterikayitpanel.Controls.Add(this.label10);
            this.musterikayitpanel.Controls.Add(this.medenihal);
            this.musterikayitpanel.Controls.Add(this.label9);
            this.musterikayitpanel.Controls.Add(this.label8);
            this.musterikayitpanel.Controls.Add(this.label5);
            this.musterikayitpanel.Controls.Add(this.label44);
            this.musterikayitpanel.Controls.Add(this.telefonnokutu);
            this.musterikayitpanel.Controls.Add(this.label3);
            this.musterikayitpanel.Controls.Add(this.adkutu);
            this.musterikayitpanel.Controls.Add(this.label2);
            this.musterikayitpanel.Controls.Add(this.label1);
            this.musterikayitpanel.Controls.Add(this.tckimliknokutu);
            this.musterikayitpanel.Location = new System.Drawing.Point(12, 13);
            this.musterikayitpanel.Name = "musterikayitpanel";
            this.musterikayitpanel.Size = new System.Drawing.Size(960, 471);
            this.musterikayitpanel.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.Location = new System.Drawing.Point(777, 131);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 15);
            this.label14.TabIndex = 37;
            this.label14.Text = "Kişilik Oda";
            // 
            // odaturukutu
            // 
            this.odaturukutu.FormattingEnabled = true;
            this.odaturukutu.Items.AddRange(new object[] {
            "2",
            "3"});
            this.odaturukutu.Location = new System.Drawing.Point(683, 128);
            this.odaturukutu.Name = "odaturukutu";
            this.odaturukutu.Size = new System.Drawing.Size(88, 22);
            this.odaturukutu.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(570, 133);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 15);
            this.label7.TabIndex = 36;
            this.label7.Text = "Oda Türü :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(48, 216);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 15);
            this.label13.TabIndex = 31;
            this.label13.Text = "Soyad :";
            // 
            // soyadkutu
            // 
            this.soyadkutu.Location = new System.Drawing.Point(178, 215);
            this.soyadkutu.Name = "soyadkutu";
            this.soyadkutu.Size = new System.Drawing.Size(182, 20);
            this.soyadkutu.TabIndex = 3;
            // 
            // temizlebutonu
            // 
            this.temizlebutonu.Location = new System.Drawing.Point(746, 328);
            this.temizlebutonu.Name = "temizlebutonu";
            this.temizlebutonu.Size = new System.Drawing.Size(101, 41);
            this.temizlebutonu.TabIndex = 14;
            this.temizlebutonu.Text = "Temizle";
            this.temizlebutonu.UseVisualStyleBackColor = true;
            this.temizlebutonu.Click += new System.EventHandler(this.temizlebutonu_Click);
            // 
            // kayitbutonu
            // 
            this.kayitbutonu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.kayitbutonu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.kayitbutonu.Location = new System.Drawing.Point(636, 328);
            this.kayitbutonu.Name = "kayitbutonu";
            this.kayitbutonu.Size = new System.Drawing.Size(101, 41);
            this.kayitbutonu.TabIndex = 13;
            this.kayitbutonu.Text = "Kayıt";
            this.kayitbutonu.UseVisualStyleBackColor = true;
            this.kayitbutonu.Click += new System.EventHandler(this.kayitbutonu_Click);
            // 
            // kalacaksurekutu
            // 
            this.kalacaksurekutu.Location = new System.Drawing.Point(683, 249);
            this.kalacaksurekutu.Name = "kalacaksurekutu";
            this.kalacaksurekutu.Size = new System.Drawing.Size(182, 20);
            this.kalacaksurekutu.TabIndex = 11;
            this.kalacaksurekutu.TextChanged += new System.EventHandler(this.kalacaksurekutu_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(570, 252);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 15);
            this.label12.TabIndex = 26;
            this.label12.Text = "Kalınacak Süre :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(570, 293);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 15);
            this.label11.TabIndex = 24;
            this.label11.Text = "Giriş Tarihi :";
            // 
            // cikistarihikutu
            // 
            this.cikistarihikutu.Location = new System.Drawing.Point(683, 293);
            this.cikistarihikutu.Name = "cikistarihikutu";
            this.cikistarihikutu.Size = new System.Drawing.Size(182, 20);
            this.cikistarihikutu.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(570, 211);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 15);
            this.label6.TabIndex = 22;
            this.label6.Text = "Giriş Tarihi :";
            // 
            // giristarihikutu
            // 
            this.giristarihikutu.Location = new System.Drawing.Point(683, 207);
            this.giristarihikutu.Name = "giristarihikutu";
            this.giristarihikutu.Size = new System.Drawing.Size(182, 20);
            this.giristarihikutu.TabIndex = 10;
            this.giristarihikutu.Value = new System.DateTime(2014, 12, 26, 0, 0, 0, 0);
            // 
            // cinsiyetkutu
            // 
            this.cinsiyetkutu.FormattingEnabled = true;
            this.cinsiyetkutu.Items.AddRange(new object[] {
            "Bay",
            "Bayan"});
            this.cinsiyetkutu.Location = new System.Drawing.Point(178, 337);
            this.cinsiyetkutu.Name = "cinsiyetkutu";
            this.cinsiyetkutu.Size = new System.Drawing.Size(182, 22);
            this.cinsiyetkutu.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(48, 340);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 15);
            this.label4.TabIndex = 19;
            this.label4.Text = "Cinsiyet :";
            // 
            // odanokutu
            // 
            this.odanokutu.FormattingEnabled = true;
            this.odanokutu.Items.AddRange(new object[] {
            "201",
            "202",
            "203",
            "204",
            "205",
            "206",
            "207",
            "208",
            "209",
            "210",
            "211",
            "212",
            "213",
            "214",
            "215",
            "301",
            "302",
            "303",
            "304",
            "305",
            "306",
            "307",
            "308",
            "309",
            "310",
            "311",
            "312",
            "313",
            "314",
            "315"});
            this.odanokutu.Location = new System.Drawing.Point(683, 165);
            this.odanokutu.Name = "odanokutu";
            this.odanokutu.Size = new System.Drawing.Size(182, 22);
            this.odanokutu.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(570, 167);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 15);
            this.label10.TabIndex = 17;
            this.label10.Text = "Oda Numarası :";
            // 
            // medenihal
            // 
            this.medenihal.FormattingEnabled = true;
            this.medenihal.Items.AddRange(new object[] {
            "Evli",
            "Bekar",
            "Dul"});
            this.medenihal.Location = new System.Drawing.Point(178, 296);
            this.medenihal.Name = "medenihal";
            this.medenihal.Size = new System.Drawing.Size(182, 22);
            this.medenihal.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(48, 298);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 15);
            this.label9.TabIndex = 15;
            this.label9.Text = "Medeni Hali :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(637, 72);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 15);
            this.label8.TabIndex = 13;
            this.label8.Text = "Oda Bilgileri";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(48, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 15);
            this.label5.TabIndex = 8;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label44.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label44.Location = new System.Drawing.Point(48, 254);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(101, 15);
            this.label44.TabIndex = 6;
            this.label44.Text = "Telefon Numarası : ";
            // 
            // telefonnokutu
            // 
            this.telefonnokutu.Location = new System.Drawing.Point(178, 253);
            this.telefonnokutu.MaxLength = 10;
            this.telefonnokutu.Name = "telefonnokutu";
            this.telefonnokutu.Size = new System.Drawing.Size(182, 20);
            this.telefonnokutu.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(48, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Adı :";
            // 
            // adkutu
            // 
            this.adkutu.Location = new System.Drawing.Point(178, 176);
            this.adkutu.Name = "adkutu";
            this.adkutu.Size = new System.Drawing.Size(182, 20);
            this.adkutu.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(48, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "T.C. Kimlik Numarası :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(124, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Kişi Bilgileri";
            // 
            // tckimliknokutu
            // 
            this.tckimliknokutu.Location = new System.Drawing.Point(178, 134);
            this.tckimliknokutu.MaxLength = 11;
            this.tckimliknokutu.Name = "tckimliknokutu";
            this.tckimliknokutu.Size = new System.Drawing.Size(182, 20);
            this.tckimliknokutu.TabIndex = 0;
            this.tckimliknokutu.TextChanged += new System.EventHandler(this.tckimliknokutu_TextChanged);
            // 
            // yenimusteri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(984, 496);
            this.Controls.Add(this.musterikayitpanel);
            this.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "yenimusteri";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Yeni Müşteri Kaydı";
            this.Load += new System.EventHandler(this.yenimusteri_Load);
            this.musterikayitpanel.ResumeLayout(false);
            this.musterikayitpanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel musterikayitpanel;
        private System.Windows.Forms.ComboBox odanokutu;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox medenihal;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox telefonnokutu;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox adkutu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tckimliknokutu;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker cikistarihikutu;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker giristarihikutu;
        private System.Windows.Forms.ComboBox cinsiyetkutu;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox kalacaksurekutu;
        private System.Windows.Forms.Button temizlebutonu;
        private System.Windows.Forms.Button kayitbutonu;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox soyadkutu;
        private System.Windows.Forms.ComboBox odaturukutu;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label14;

    }
}